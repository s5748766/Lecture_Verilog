/**
  ******************************************************************************
  * @file    sd_spi_driver.c (Clean Version - No Debug Messages)
  * @brief   SD Card SPI driver - Production version
  ******************************************************************************
  */

#include "sd_spi_driver.h"
#include "main.h"

/* External SPI handle */
extern SPI_HandleTypeDef hspi1;

/* CS Pin Control Macros */
#define SD_CS_LOW()     HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET)
#define SD_CS_HIGH()    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET)

/* Private variables */
static uint8_t CardType = 0;

/* Private function prototypes */
static uint8_t SD_SendCommand(uint8_t cmd, uint32_t arg);
static uint8_t SD_WaitReady(uint32_t timeout);
static void SD_PowerOn(void);
static uint8_t SD_RxByte(void);
static void SD_TxByte(uint8_t data);
static void SD_SetSpeed(uint8_t speed);

/**
  * @brief  SPI Transmit single byte
  */
static void SD_TxByte(uint8_t data)
{
    HAL_SPI_Transmit(&hspi1, &data, 1, 100);
}

/**
  * @brief  SPI Receive single byte
  */
static uint8_t SD_RxByte(void)
{
    uint8_t dummy = 0xFF, data;
    HAL_SPI_TransmitReceive(&hspi1, &dummy, &data, 1, 100);
    return data;
}

/**
  * @brief  Set SPI speed
  */
static void SD_SetSpeed(uint8_t speed)
{
    if (speed == 0) {
        hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_128;
    } else {
        hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
    }
    HAL_SPI_Init(&hspi1);
}

/**
  * @brief  Power on the SD card
  */
static void SD_PowerOn(void)
{
    SD_CS_HIGH();
    for (uint8_t i = 0; i < 10; i++) {
        SD_TxByte(0xFF);
    }
}

/**
  * @brief  Wait for card ready
  */
static uint8_t SD_WaitReady(uint32_t timeout)
{
    uint8_t res;
    uint32_t start = HAL_GetTick();

    SD_RxByte();
    do {
        res = SD_RxByte();
        if (res == 0xFF) return 0xFF;
    } while ((HAL_GetTick() - start) < timeout);

    return res;
}

/**
  * @brief  Send command to SD card
  */
static uint8_t SD_SendCommand(uint8_t cmd, uint32_t arg)
{
    uint8_t res, crc = 0x01;

    if (cmd & 0x80) {
        cmd &= 0x7F;
        res = SD_SendCommand(SD_CMD55, 0);
        if (res > 1) return res;
    }

    SD_CS_HIGH();
    SD_RxByte();
    SD_CS_LOW();
    SD_RxByte();

    if (SD_WaitReady(500) != 0xFF) {
        SD_CS_HIGH();
        return 0xFF;
    }

    SD_TxByte(cmd);
    SD_TxByte((uint8_t)(arg >> 24));
    SD_TxByte((uint8_t)(arg >> 16));
    SD_TxByte((uint8_t)(arg >> 8));
    SD_TxByte((uint8_t)arg);

    if (cmd == SD_CMD0) crc = 0x95;
    if (cmd == SD_CMD8) crc = 0x87;
    SD_TxByte(crc);

    if (cmd == SD_CMD12) SD_RxByte();

    uint8_t n = 10;
    do {
        res = SD_RxByte();
    } while ((res & 0x80) && --n);

    return res;
}

/**
  * @brief  Initialize SD card
  */
uint8_t SD_SPI_Init(void)
{
    uint8_t n, cmd, ty = 0;
    uint8_t ocr[4];

    SD_SetSpeed(0);
    SD_PowerOn();

    if (SD_SendCommand(SD_CMD0, 0) == 1) {
        if (SD_SendCommand(SD_CMD8, 0x1AA) == 1) {
            /* SDv2 */
            for (n = 0; n < 4; n++) ocr[n] = SD_RxByte();

            if (ocr[2] == 0x01 && ocr[3] == 0xAA) {
                uint32_t start = HAL_GetTick();
                while ((HAL_GetTick() - start) < 1000) {
                    if (SD_SendCommand(SD_CMD41 | 0x80, 1UL << 30) == 0) break;
                    HAL_Delay(10);
                }

                if ((HAL_GetTick() - start) < 1000 && SD_SendCommand(SD_CMD58, 0) == 0) {
                    for (n = 0; n < 4; n++) ocr[n] = SD_RxByte();
                    ty = (ocr[0] & 0x40) ? CT_SD2 | CT_BLOCK : CT_SD2;
                }
            }
        } else {
            /* SDv1 or MMC */
            if (SD_SendCommand(SD_CMD55 | 0x80, 0) <= 1) {
                ty = CT_SD1;
                cmd = SD_CMD41 | 0x80;
            } else {
                ty = CT_MMC;
                cmd = SD_CMD1;
            }

            uint32_t start = HAL_GetTick();
            while ((HAL_GetTick() - start) < 1000) {
                if (SD_SendCommand(cmd, 0) == 0) break;
                HAL_Delay(10);
            }

            if ((HAL_GetTick() - start) >= 1000 || SD_SendCommand(SD_CMD16, 512) != 0) {
                ty = 0;
            }
        }
    }

    CardType = ty;
    SD_CS_HIGH();
    SD_RxByte();

    if (ty) {
        SD_SetSpeed(1);
        return 0;
    }

    return 1;
}

/**
  * @brief  Read single block
  */
uint8_t SD_SPI_ReadBlock(uint8_t *buf, uint32_t sector)
{
    uint8_t result = 1;

    if (!(CardType & CT_BLOCK)) sector *= 512;

    if (SD_SendCommand(SD_CMD17, sector) == 0) {
        uint32_t timeout = 200;
        uint8_t token;

        do {
            token = SD_RxByte();
            if (token == 0xFE) break;
            HAL_Delay(1);
        } while (--timeout);

        if (token == 0xFE) {
            for (uint16_t i = 0; i < 512; i++) {
                buf[i] = SD_RxByte();
            }
            SD_RxByte();
            SD_RxByte();
            result = 0;
        }
    }

    SD_CS_HIGH();
    SD_RxByte();

    return result;
}

/**
  * @brief  Write single block
  */
uint8_t SD_SPI_WriteBlock(const uint8_t *buf, uint32_t sector)
{
    uint8_t result = 1;

    if (!(CardType & CT_BLOCK)) sector *= 512;

    if (SD_SendCommand(SD_CMD24, sector) == 0) {
        if (SD_WaitReady(500) == 0xFF) {
            SD_TxByte(0xFE);

            for (uint16_t i = 0; i < 512; i++) {
                SD_TxByte(buf[i]);
            }

            SD_TxByte(0xFF);
            SD_TxByte(0xFF);

            uint8_t resp = SD_RxByte();
            if ((resp & 0x1F) == 0x05) {
                if (SD_WaitReady(500) == 0xFF) {
                    result = 0;
                }
            }
        }
    }

    SD_CS_HIGH();
    SD_RxByte();

    return result;
}

/**
  * @brief  Read multiple blocks
  */
uint8_t SD_SPI_ReadMultiBlock(uint8_t *buf, uint32_t sector, uint32_t count)
{
    if (!(CardType & CT_BLOCK)) sector *= 512;

    if (SD_SendCommand(SD_CMD18, sector) == 0) {
        for (uint32_t i = 0; i < count; i++) {
            uint32_t timeout = 200;
            uint8_t token;

            do {
                token = SD_RxByte();
                if (token == 0xFE) break;
                HAL_Delay(1);
            } while (--timeout);

            if (token != 0xFE) {
                SD_SendCommand(SD_CMD12, 0);
                SD_CS_HIGH();
                return 1;
            }

            for (uint16_t j = 0; j < 512; j++) {
                buf[j] = SD_RxByte();
            }
            buf += 512;

            SD_RxByte();
            SD_RxByte();
        }

        SD_SendCommand(SD_CMD12, 0);
    }

    SD_CS_HIGH();
    SD_RxByte();

    return 0;
}

/**
  * @brief  Write multiple blocks
  */
uint8_t SD_SPI_WriteMultiBlock(const uint8_t *buf, uint32_t sector, uint32_t count)
{
    if (!(CardType & CT_BLOCK)) sector *= 512;

    if (CardType & CT_SDC) {
        SD_SendCommand(SD_CMD55 | 0x80, 0);
        SD_SendCommand(SD_CMD23, count);
    }

    if (SD_SendCommand(SD_CMD25, sector) == 0) {
        for (uint32_t i = 0; i < count; i++) {
            if (SD_WaitReady(500) != 0xFF) break;

            SD_TxByte(0xFC);

            for (uint16_t j = 0; j < 512; j++) {
                SD_TxByte(buf[j]);
            }
            buf += 512;

            SD_TxByte(0xFF);
            SD_TxByte(0xFF);

            uint8_t resp = SD_RxByte();
            if ((resp & 0x1F) != 0x05) break;
        }

        SD_TxByte(0xFD);
        SD_WaitReady(500);
    }

    SD_CS_HIGH();
    SD_RxByte();

    return 0;
}

/**
  * @brief  Get card info
  */
uint8_t SD_SPI_GetCardInfo(void)
{
    return CardType;
}
