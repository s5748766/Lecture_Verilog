/**
  ******************************************************************************
  * @file    sd_spi_driver.h
  * @brief   SD Card SPI driver header
  * @note    Core/Inc 폴더에 추가하세요
  ******************************************************************************
  */

#ifndef __SD_SPI_DRIVER_H
#define __SD_SPI_DRIVER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"

/* SD Card Commands */
#define SD_CMD0     0x40  /* GO_IDLE_STATE */
#define SD_CMD1     0x41  /* SEND_OP_COND (MMC) */
#define SD_CMD8     0x48  /* SEND_IF_COND */
#define SD_CMD9     0x49  /* SEND_CSD */
#define SD_CMD10    0x4A  /* SEND_CID */
#define SD_CMD12    0x4C  /* STOP_TRANSMISSION */
#define SD_CMD16    0x50  /* SET_BLOCKLEN */
#define SD_CMD17    0x51  /* READ_SINGLE_BLOCK */
#define SD_CMD18    0x52  /* READ_MULTIPLE_BLOCK */
#define SD_CMD23    0x57  /* SET_BLOCK_COUNT (MMC) */
#define SD_CMD24    0x58  /* WRITE_BLOCK */
#define SD_CMD25    0x59  /* WRITE_MULTIPLE_BLOCK */
#define SD_CMD41    0x69  /* SEND_OP_COND (SDC) */
#define SD_CMD55    0x77  /* APP_CMD */
#define SD_CMD58    0x7A  /* READ_OCR */

/* Card type flags */
#define CT_MMC      0x01  /* MMC ver 3 */
#define CT_SD1      0x02  /* SD ver 1 */
#define CT_SD2      0x04  /* SD ver 2 */
#define CT_SDC      (CT_SD1|CT_SD2)
#define CT_BLOCK    0x08  /* Block addressing */

/* Function Prototypes */
uint8_t SD_SPI_Init(void);
uint8_t SD_SPI_ReadBlock(uint8_t *buf, uint32_t sector);
uint8_t SD_SPI_WriteBlock(const uint8_t *buf, uint32_t sector);
uint8_t SD_SPI_ReadMultiBlock(uint8_t *buf, uint32_t sector, uint32_t count);
uint8_t SD_SPI_WriteMultiBlock(const uint8_t *buf, uint32_t sector, uint32_t count);
uint8_t SD_SPI_GetCardInfo(void);

#ifdef __cplusplus
}
#endif

#endif /* __SD_SPI_DRIVER_H */
